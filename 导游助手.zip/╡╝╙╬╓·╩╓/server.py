from flask import Flask, request
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from loguru import logger
import json
import os
import datetime
import re
import time
import uuid
from openai import OpenAI

# 配置日志记录，每次启动服务器创建一个新的日志文件
log_dir = 'logs'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 日志文件名：端口号+日期+时间
log_filename = os.path.join(log_dir, f"5000_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log")
logger.add(log_filename, rotation="00:00", encoding='utf-8')

client_messages = {}
client_files = {}  # 用于存储每个客户端的文件对象
client_q_a = {}    # 用于存储每个客户端的 q_a 列表

if not os.path.exists('data'):
    os.makedirs('data')

# 假设你有一个 OpenAI 客户端（根据你的 API 配置）
client = OpenAI(api_key="sk-a46de6af7d2040369632dccff859f93d", base_url="https://api.deepseek.com/")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
CORS(app, resources={r'*': {'origins': 'http://localhost:8000'}})
socketio = SocketIO(app, cors_allowed_origins='http://localhost:8000')

# 知识库文件夹路径
KNOWLEDGE_BASES_DIR = 'knowledge bases'

# 关键词到文件名的映射
keyword_to_filename = {
    '图书馆': '图书馆 knowledge base.json',
    '丽泽楼': '丽泽楼 knowledge base.json',
    '励耘楼': '励耘楼 knowledge base.json',
    '木铎楼': '木铎楼 knowledge base.json',
    '校名石': '校名石 knowledge base.json',
    'default': 'default knowledge base.json'
}

# 加载知识库文件
def load_knowledge_base(file_name):
    file_path = os.path.join(KNOWLEDGE_BASES_DIR, file_name)
    logger.info(f"尝试加载知识库文件: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"知识库文件不存在: {file_path}")
        return None
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            knowledge_base = json.load(f)
            # 提取“问题与回答”部分
            q_a = extract_q_a(knowledge_base)
            return {
                "主题": knowledge_base.get("主题", "未知主题"),
                "内容": knowledge_base.get("内容", "未知内容"),
                "q_a": q_a
            }
    except json.JSONDecodeError as e:
        logger.error(f"知识库文件格式错误: {file_path}, 错误: {e}")
        return None

# 递归提取问题和回答
def extract_q_a(data):
    q_a = []
    if isinstance(data, dict):
        if "问题" in data and "回答" in data:
            q_a.append({
                "问题": data["问题"],
                "回答": data["回答"]
            })
        for key, value in data.items():
            q_a.extend(extract_q_a(value))
    elif isinstance(data, list):
        for item in data:
            q_a.extend(extract_q_a(item))
    return q_a

# 运行对话
def run(messages):
    try:
        start_time = time.time()
        response = client.chat.completions.create(
            model="deepseek-coder",
            messages=messages,
            timeout=200,
            max_tokens=2048
        )
        result = response.choices[0].message.content
        elapsed_time = time.time() - start_time
        logger.info(f"对话成功, 耗时: {elapsed_time:.2f}秒")
        return {"result": result, "time": elapsed_time}
    except Exception as e:
        logger.error(f"对话失败: {e}")
        return {"result": "对话失败，请稍后再试。", "time": None}

# 处理客户端连接
@socketio.on('connect')
def handle_connect():
    sid = request.sid
    logger.info(f'Client connected: {sid}')

    # 生成一个可读的文件名（使用 UUID 替换 sid）
    readable_id = str(uuid.uuid4())[:8]  # 取 UUID 的前 8 个字符
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    data_filename = os.path.join('data', f"{readable_id}_{timestamp}.jsonl")

    # 为每个客户端创建一个文件，用于存储聊天记录
    client_files[sid] = open(data_filename, 'a', encoding='utf-8')

    # 初始化系统提示，使用默认知识库
    default_knowledge_base = load_knowledge_base("default knowledge base.json")
    if default_knowledge_base is None or '主题' not in default_knowledge_base or '内容' not in default_knowledge_base:
        logger.error("默认知识库文件格式错误或缺少必要字段")
        default_knowledge_base = {
            "主题": "默认主题",
            "内容": "默认内容",
            "q_a": []
        }

    client_messages[sid] = [
        {"role": "system",
         "content": f"你是智能聊天机器人，当前主题是：{default_knowledge_base['主题']}\n{default_knowledge_base['内容']}"},
    ]

    # 存储 q_a
    client_q_a[sid] = default_knowledge_base.get('q_a', [])

# 处理客户端消息
@socketio.on('message')
def handle_message(msg):
    sid = request.sid

    # 检查用户是否输入了关键词（例如 #图书馆）
    keyword_match = re.search(r'#([^#]+)', msg)
    if keyword_match:
        keyword = keyword_match.group(1).strip()  # 提取关键词并去除前后空白
        logger.info(f"用户输入关键词: {keyword}")

        # 根据关键词查找对应的文件名
        file_name = keyword_to_filename.get(keyword, "default knowledge base.json")

        # 加载知识库
        knowledge_base = load_knowledge_base(file_name)
        if knowledge_base is None or '主题' not in knowledge_base or '内容' not in knowledge_base:
            logger.error(f"知识库文件格式错误或缺少必要字段: {file_name}")
            knowledge_base = load_knowledge_base("default knowledge base.json")  # 默认知识库

        # 更新系统提示
        client_messages[sid] = [
            {"role": "system",
             "content": f"你是智能聊天机器人，当前主题是：{knowledge_base['主题']}\n{knowledge_base['内容']}"},
        ]

        # 更新 q_a
        client_q_a[sid] = knowledge_base.get('q_a', [])

        # 发送确认消息给用户
        emit('response', {'content': f"已切换到主题：{knowledge_base['主题']}"})
        return  # 结束处理，不继续对话

    # 如果没有关键词，继续正常对话
    if sid not in client_messages:
        client_messages[sid] = [
            {"role": "system", "content": "你是智能聊天机器人，当前主题是通用知识。"},
        ]
    client_messages[sid].append({"role": "user", "content": msg})

    # 检查是否有匹配的预设问题
    for qa in client_q_a.get(sid, []):
        if '问题' in qa and '回答' in qa:
            # 提取预设问题的关键词
            keywords = re.findall(r'\w+', qa['问题'])
            # 检查用户消息中是否包含所有关键词
            if all(keyword in msg for keyword in keywords):
                response = qa['回答']
                emit('response', {'content': response})
                # 将问答记录加入消息历史
                client_messages[sid].append({"role": "assistant", "content": response})
                # 写入聊天记录文件
                if sid in client_files:
                    json_line = json.dumps({"question": msg, "response": response, "time": 0}, ensure_ascii=False)
                    client_files[sid].write(json_line + '\n')
                return

    # 如果没有匹配的预设问题，则调用模型生成回答
    time.sleep(1)
    response_data = run(client_messages[sid])
    response = response_data["result"]
    elapsed_time = response_data["time"]
    client_messages[sid].append({"role": "assistant", "content": response})
    response = re.sub(r'（[^）]*）', '', response).strip()
    if elapsed_time is not None:
        response_with_time = f"{response} （耗时{elapsed_time:.2f}秒）"
    else:
        response_with_time = f"{response} （请求失败）"
    emit('response', {'content': response_with_time, 'time': elapsed_time})

    # 将聊天记录写入文件
    if sid in client_files:
        json_line = json.dumps({"question": msg, "response": response, "time": elapsed_time}, ensure_ascii=False)
        client_files[sid].write(json_line + '\n')

# 处理客户端断开连接
@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    logger.info(f'Client disconnected: {sid}')
    if sid in client_messages:
        del client_messages[sid]
    if sid in client_files:
        client_files[sid].close()
        del client_files[sid]
    if sid in client_q_a:
        del client_q_a[sid]

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)